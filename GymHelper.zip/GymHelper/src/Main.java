import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter probable time of your training in minutes:");
        int time = scan.nextInt();
        System.out.println("Enter part of the body for training from the following list:");
        System.out.println("Back");
        System.out.println("Циці");
        System.out.println("Shoulders");
        System.out.println("Arms");
        System.out.println("Legs");
        String train = scan.nextLine();





    }
}